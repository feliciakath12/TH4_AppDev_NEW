﻿namespace W4_Take_Home
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_SoccerTeamList = new System.Windows.Forms.Label();
            this.lb_Country = new System.Windows.Forms.Label();
            this.lb_Team = new System.Windows.Forms.Label();
            this.lb_AddingPlayers = new System.Windows.Forms.Label();
            this.lb_AddingTeam = new System.Windows.Forms.Label();
            this.cbx_Country = new System.Windows.Forms.ComboBox();
            this.cbx_Team = new System.Windows.Forms.ComboBox();
            this.lb_TeamName = new System.Windows.Forms.Label();
            this.lb_TeamCountry = new System.Windows.Forms.Label();
            this.lb_TeamCity = new System.Windows.Forms.Label();
            this.tb_TName = new System.Windows.Forms.TextBox();
            this.tb_TCountry = new System.Windows.Forms.TextBox();
            this.tb_TCity = new System.Windows.Forms.TextBox();
            this.tb_PNumber = new System.Windows.Forms.TextBox();
            this.tb_PName = new System.Windows.Forms.TextBox();
            this.lb_PlayerPosition = new System.Windows.Forms.Label();
            this.lb_PlayerNumber = new System.Windows.Forms.Label();
            this.lb_PlayerName = new System.Windows.Forms.Label();
            this.cbx_PPosition = new System.Windows.Forms.ComboBox();
            this.btn_AddT = new System.Windows.Forms.Button();
            this.btn_AddP = new System.Windows.Forms.Button();
            this.btn_Remove = new System.Windows.Forms.Button();
            this.lbx_PlayerList = new System.Windows.Forms.ListBox();
            this.SuspendLayout();
            // 
            // lb_SoccerTeamList
            // 
            this.lb_SoccerTeamList.AutoSize = true;
            this.lb_SoccerTeamList.Location = new System.Drawing.Point(12, 59);
            this.lb_SoccerTeamList.Name = "lb_SoccerTeamList";
            this.lb_SoccerTeamList.Size = new System.Drawing.Size(132, 20);
            this.lb_SoccerTeamList.TabIndex = 0;
            this.lb_SoccerTeamList.Text = "Soccer Team List";
            // 
            // lb_Country
            // 
            this.lb_Country.AutoSize = true;
            this.lb_Country.Location = new System.Drawing.Point(12, 113);
            this.lb_Country.Name = "lb_Country";
            this.lb_Country.Size = new System.Drawing.Size(127, 20);
            this.lb_Country.TabIndex = 1;
            this.lb_Country.Text = "Choose Country:";
            // 
            // lb_Team
            // 
            this.lb_Team.AutoSize = true;
            this.lb_Team.Location = new System.Drawing.Point(12, 162);
            this.lb_Team.Name = "lb_Team";
            this.lb_Team.Size = new System.Drawing.Size(112, 20);
            this.lb_Team.TabIndex = 2;
            this.lb_Team.Text = "Choose Team:";
            // 
            // lb_AddingPlayers
            // 
            this.lb_AddingPlayers.AutoSize = true;
            this.lb_AddingPlayers.Location = new System.Drawing.Point(668, 59);
            this.lb_AddingPlayers.Name = "lb_AddingPlayers";
            this.lb_AddingPlayers.Size = new System.Drawing.Size(114, 20);
            this.lb_AddingPlayers.TabIndex = 3;
            this.lb_AddingPlayers.Text = "Adding Players";
            // 
            // lb_AddingTeam
            // 
            this.lb_AddingTeam.AutoSize = true;
            this.lb_AddingTeam.Location = new System.Drawing.Point(338, 59);
            this.lb_AddingTeam.Name = "lb_AddingTeam";
            this.lb_AddingTeam.Size = new System.Drawing.Size(103, 20);
            this.lb_AddingTeam.TabIndex = 4;
            this.lb_AddingTeam.Text = "Adding Team";
            // 
            // cbx_Country
            // 
            this.cbx_Country.FormattingEnabled = true;
            this.cbx_Country.Items.AddRange(new object[] {
            "England",
            "Germany"});
            this.cbx_Country.Location = new System.Drawing.Point(145, 110);
            this.cbx_Country.Name = "cbx_Country";
            this.cbx_Country.Size = new System.Drawing.Size(157, 28);
            this.cbx_Country.TabIndex = 5;
            this.cbx_Country.SelectedIndexChanged += new System.EventHandler(this.cbx_Country_SelectedIndexChanged);
            // 
            // cbx_Team
            // 
            this.cbx_Team.FormattingEnabled = true;
            this.cbx_Team.Location = new System.Drawing.Point(145, 159);
            this.cbx_Team.Name = "cbx_Team";
            this.cbx_Team.Size = new System.Drawing.Size(157, 28);
            this.cbx_Team.TabIndex = 6;
            this.cbx_Team.SelectedIndexChanged += new System.EventHandler(this.cbx_Team_SelectedIndexChanged);
            // 
            // lb_TeamName
            // 
            this.lb_TeamName.AutoSize = true;
            this.lb_TeamName.Location = new System.Drawing.Point(338, 113);
            this.lb_TeamName.Name = "lb_TeamName";
            this.lb_TeamName.Size = new System.Drawing.Size(99, 20);
            this.lb_TeamName.TabIndex = 7;
            this.lb_TeamName.Text = "Team Name:";
            // 
            // lb_TeamCountry
            // 
            this.lb_TeamCountry.AutoSize = true;
            this.lb_TeamCountry.Location = new System.Drawing.Point(338, 162);
            this.lb_TeamCountry.Name = "lb_TeamCountry";
            this.lb_TeamCountry.Size = new System.Drawing.Size(112, 20);
            this.lb_TeamCountry.TabIndex = 8;
            this.lb_TeamCountry.Text = "Team Country:";
            // 
            // lb_TeamCity
            // 
            this.lb_TeamCity.AutoSize = true;
            this.lb_TeamCity.Location = new System.Drawing.Point(338, 209);
            this.lb_TeamCity.Name = "lb_TeamCity";
            this.lb_TeamCity.Size = new System.Drawing.Size(83, 20);
            this.lb_TeamCity.TabIndex = 9;
            this.lb_TeamCity.Text = "Team City:";
            // 
            // tb_TName
            // 
            this.tb_TName.Location = new System.Drawing.Point(467, 110);
            this.tb_TName.Name = "tb_TName";
            this.tb_TName.Size = new System.Drawing.Size(151, 26);
            this.tb_TName.TabIndex = 10;
            // 
            // tb_TCountry
            // 
            this.tb_TCountry.Location = new System.Drawing.Point(467, 159);
            this.tb_TCountry.Name = "tb_TCountry";
            this.tb_TCountry.Size = new System.Drawing.Size(151, 26);
            this.tb_TCountry.TabIndex = 11;
            // 
            // tb_TCity
            // 
            this.tb_TCity.Location = new System.Drawing.Point(467, 206);
            this.tb_TCity.Name = "tb_TCity";
            this.tb_TCity.Size = new System.Drawing.Size(151, 26);
            this.tb_TCity.TabIndex = 12;
            // 
            // tb_PNumber
            // 
            this.tb_PNumber.Location = new System.Drawing.Point(805, 156);
            this.tb_PNumber.Name = "tb_PNumber";
            this.tb_PNumber.Size = new System.Drawing.Size(151, 26);
            this.tb_PNumber.TabIndex = 17;
            // 
            // tb_PName
            // 
            this.tb_PName.Location = new System.Drawing.Point(805, 107);
            this.tb_PName.Name = "tb_PName";
            this.tb_PName.Size = new System.Drawing.Size(151, 26);
            this.tb_PName.TabIndex = 16;
            // 
            // lb_PlayerPosition
            // 
            this.lb_PlayerPosition.AutoSize = true;
            this.lb_PlayerPosition.Location = new System.Drawing.Point(676, 206);
            this.lb_PlayerPosition.Name = "lb_PlayerPosition";
            this.lb_PlayerPosition.Size = new System.Drawing.Size(116, 20);
            this.lb_PlayerPosition.TabIndex = 15;
            this.lb_PlayerPosition.Text = "Player Position:";
            // 
            // lb_PlayerNumber
            // 
            this.lb_PlayerNumber.AutoSize = true;
            this.lb_PlayerNumber.Location = new System.Drawing.Point(676, 159);
            this.lb_PlayerNumber.Name = "lb_PlayerNumber";
            this.lb_PlayerNumber.Size = new System.Drawing.Size(116, 20);
            this.lb_PlayerNumber.TabIndex = 14;
            this.lb_PlayerNumber.Text = "Player Number:";
            // 
            // lb_PlayerName
            // 
            this.lb_PlayerName.AutoSize = true;
            this.lb_PlayerName.Location = new System.Drawing.Point(676, 110);
            this.lb_PlayerName.Name = "lb_PlayerName";
            this.lb_PlayerName.Size = new System.Drawing.Size(102, 20);
            this.lb_PlayerName.TabIndex = 13;
            this.lb_PlayerName.Text = "Player Name:";
            // 
            // cbx_PPosition
            // 
            this.cbx_PPosition.FormattingEnabled = true;
            this.cbx_PPosition.Location = new System.Drawing.Point(805, 206);
            this.cbx_PPosition.Name = "cbx_PPosition";
            this.cbx_PPosition.Size = new System.Drawing.Size(151, 28);
            this.cbx_PPosition.TabIndex = 18;
            // 
            // btn_AddT
            // 
            this.btn_AddT.Location = new System.Drawing.Point(467, 253);
            this.btn_AddT.Name = "btn_AddT";
            this.btn_AddT.Size = new System.Drawing.Size(102, 43);
            this.btn_AddT.TabIndex = 19;
            this.btn_AddT.Text = "Add";
            this.btn_AddT.UseVisualStyleBackColor = true;
            this.btn_AddT.Click += new System.EventHandler(this.btn_AddT_Click);
            // 
            // btn_AddP
            // 
            this.btn_AddP.Location = new System.Drawing.Point(805, 253);
            this.btn_AddP.Name = "btn_AddP";
            this.btn_AddP.Size = new System.Drawing.Size(102, 43);
            this.btn_AddP.TabIndex = 20;
            this.btn_AddP.Text = "Add";
            this.btn_AddP.UseVisualStyleBackColor = true;
            this.btn_AddP.Click += new System.EventHandler(this.btn_AddP_Click);
            // 
            // btn_Remove
            // 
            this.btn_Remove.Location = new System.Drawing.Point(16, 395);
            this.btn_Remove.Name = "btn_Remove";
            this.btn_Remove.Size = new System.Drawing.Size(95, 44);
            this.btn_Remove.TabIndex = 21;
            this.btn_Remove.Text = "Remove";
            this.btn_Remove.UseVisualStyleBackColor = true;
            this.btn_Remove.Click += new System.EventHandler(this.btn_Remove_Click);
            // 
            // lbx_PlayerList
            // 
            this.lbx_PlayerList.FormattingEnabled = true;
            this.lbx_PlayerList.ItemHeight = 20;
            this.lbx_PlayerList.Location = new System.Drawing.Point(16, 225);
            this.lbx_PlayerList.Name = "lbx_PlayerList";
            this.lbx_PlayerList.Size = new System.Drawing.Size(286, 164);
            this.lbx_PlayerList.TabIndex = 22;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1000, 471);
            this.Controls.Add(this.lbx_PlayerList);
            this.Controls.Add(this.btn_Remove);
            this.Controls.Add(this.btn_AddP);
            this.Controls.Add(this.btn_AddT);
            this.Controls.Add(this.cbx_PPosition);
            this.Controls.Add(this.tb_PNumber);
            this.Controls.Add(this.tb_PName);
            this.Controls.Add(this.lb_PlayerPosition);
            this.Controls.Add(this.lb_PlayerNumber);
            this.Controls.Add(this.lb_PlayerName);
            this.Controls.Add(this.tb_TCity);
            this.Controls.Add(this.tb_TCountry);
            this.Controls.Add(this.tb_TName);
            this.Controls.Add(this.lb_TeamCity);
            this.Controls.Add(this.lb_TeamCountry);
            this.Controls.Add(this.lb_TeamName);
            this.Controls.Add(this.cbx_Team);
            this.Controls.Add(this.cbx_Country);
            this.Controls.Add(this.lb_AddingTeam);
            this.Controls.Add(this.lb_AddingPlayers);
            this.Controls.Add(this.lb_Team);
            this.Controls.Add(this.lb_Country);
            this.Controls.Add(this.lb_SoccerTeamList);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lb_SoccerTeamList;
        private System.Windows.Forms.Label lb_Country;
        private System.Windows.Forms.Label lb_Team;
        private System.Windows.Forms.Label lb_AddingPlayers;
        private System.Windows.Forms.Label lb_AddingTeam;
        private System.Windows.Forms.ComboBox cbx_Country;
        private System.Windows.Forms.ComboBox cbx_Team;
        private System.Windows.Forms.Label lb_TeamName;
        private System.Windows.Forms.Label lb_TeamCountry;
        private System.Windows.Forms.Label lb_TeamCity;
        private System.Windows.Forms.TextBox tb_TName;
        private System.Windows.Forms.TextBox tb_TCountry;
        private System.Windows.Forms.TextBox tb_TCity;
        private System.Windows.Forms.TextBox tb_PNumber;
        private System.Windows.Forms.TextBox tb_PName;
        private System.Windows.Forms.Label lb_PlayerPosition;
        private System.Windows.Forms.Label lb_PlayerNumber;
        private System.Windows.Forms.Label lb_PlayerName;
        private System.Windows.Forms.ComboBox cbx_PPosition;
        private System.Windows.Forms.Button btn_AddT;
        private System.Windows.Forms.Button btn_AddP;
        private System.Windows.Forms.Button btn_Remove;
        private System.Windows.Forms.ListBox lbx_PlayerList;
    }
}

